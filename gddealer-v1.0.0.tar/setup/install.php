<?php
/**
 * @brief       GD Dealer Manager — Install routine
 * @package     IPS Community Suite
 * @subpackage  GD Dealer Manager
 * @since       15 Apr 2026
 *
 * Runs after schema.json tables are created. Seeds templates directly into
 * core_theme_templates using nowdoc heredocs so real newlines/tabs are
 * preserved. No comments inside template bodies (Rule #9) — the IPS
 * template compiler does not parse comment syntax.
 */

$gddealerTemplates = [

	/* ===== ADMIN: dashboard ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'admin',
		'group'         => 'dealers',
		'template_name' => 'dashboard',
		'template_data' => '$totalDealers, $activeDealers, $suspendedDealers, $totalListings, $inStockListings, $unmatchedTotal, $lastRunTime, $lastRunStatus, $tierCounts, $dealersUrl, $mrrUrl, $unmatchedUrl',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div class="ipsBox_body ipsPad">

		<div style="display:flex;gap:16px;margin-bottom:24px;flex-wrap:wrap">
			<div class="ipsBox" style="flex:1 1 150px;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$totalDealers}</div>
				<div>{lang="gddealer_dash_total_dealers"}</div>
			</div>
			<div class="ipsBox" style="flex:1 1 150px;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold;color:#2a8a2a">{$activeDealers}</div>
				<div>{lang="gddealer_dash_active_dealers"}</div>
			</div>
			<div class="ipsBox" style="flex:1 1 150px;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold;color:#c00">{$suspendedDealers}</div>
				<div>{lang="gddealer_dash_suspended_dealers"}</div>
			</div>
			<div class="ipsBox" style="flex:1 1 150px;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{expression="number_format( $totalListings )"}</div>
				<div>{lang="gddealer_dash_total_listings"}</div>
			</div>
			<div class="ipsBox" style="flex:1 1 150px;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{expression="number_format( $inStockListings )"}</div>
				<div>{lang="gddealer_dash_in_stock_listings"}</div>
			</div>
			<div class="ipsBox" style="flex:1 1 150px;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{expression="number_format( $unmatchedTotal )"}</div>
				<div>{lang="gddealer_dash_unmatched_total"}</div>
			</div>
		</div>

		<h2>Subscription Tier Breakdown</h2>
		<table class="ipsTable ipsTable_zebra" style="width:100%;margin-bottom:24px">
			<thead>
				<tr><th>Tier</th><th>Dealers</th></tr>
			</thead>
			<tbody>
				<tr><td><strong>Basic</strong></td><td>{$tierCounts['basic']}</td></tr>
				<tr><td><strong>Pro</strong></td><td>{$tierCounts['pro']}</td></tr>
				<tr><td><strong>Enterprise</strong></td><td>{$tierCounts['enterprise']}</td></tr>
				<tr><td><strong>Founding</strong></td><td>{$tierCounts['founding']}</td></tr>
			</tbody>
		</table>

		<h2>{lang="gddealer_dash_last_run"}</h2>
		<p>
			{{if $lastRunTime}}
				{$lastRunTime} &mdash;
				{{if $lastRunStatus === 'completed'}}
					<span class="ipsBadge ipsBadge--positive">Completed</span>
				{{elseif $lastRunStatus === 'failed'}}
					<span class="ipsBadge ipsBadge--negative">Failed</span>
				{{elseif $lastRunStatus === 'running'}}
					<span class="ipsBadge ipsBadge--warning">Running</span>
				{{else}}
					<span class="ipsBadge ipsBadge--neutral">{$lastRunStatus}</span>
				{{endif}}
			{{else}}
				<em>No imports have run yet.</em>
			{{endif}}
		</p>

		<div style="margin-top:24px">
			<a href="{$dealersUrl}" class="ipsButton ipsButton--primary">Manage Dealers</a>
			<a href="{$mrrUrl}" class="ipsButton ipsButton--normal">MRR Dashboard</a>
			<a href="{$unmatchedUrl}" class="ipsButton ipsButton--normal">Unmatched UPCs</a>
		</div>

	</div>
</div>
TEMPLATE_EOT,
	],

	/* ===== ADMIN: dealerList ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'admin',
		'group'         => 'dealers',
		'template_name' => 'dealerList',
		'template_data' => '$dealers, $onboardUrl',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div class="ipsBox_body ipsPad">

		<div style="margin-bottom:16px">
			<a href="{$onboardUrl}" class="ipsButton ipsButton--primary">{lang="gddealer_onboard_button"}</a>
		</div>

		<table class="ipsTable ipsTable_zebra" style="width:100%">
			<thead>
				<tr>
					<th>{lang="gddealer_dealer_name"}</th>
					<th>{lang="gddealer_dealer_tier"}</th>
					<th>{lang="gddealer_dealer_status"}</th>
					<th>{lang="gddealer_dealer_listing_count"}</th>
					<th>{lang="gddealer_dealer_last_import"}</th>
					<th>{lang="gddealer_dealer_mrr"}</th>
					<th>{lang="gddealer_dealer_actions"}</th>
				</tr>
			</thead>
			<tbody>
				{{foreach $dealers as $d}}
				<tr>
					<td><strong>{$d['dealer_name']}</strong><br><small>ID {$d['dealer_id']}</small></td>
					<td>
						{{if $d['subscription_tier'] === 'enterprise'}}
							<span class="ipsBadge ipsBadge--positive">Enterprise</span>
						{{elseif $d['subscription_tier'] === 'pro'}}
							<span class="ipsBadge ipsBadge--style1">Pro</span>
						{{elseif $d['subscription_tier'] === 'founding'}}
							<span class="ipsBadge ipsBadge--warning">Founding</span>
						{{else}}
							<span class="ipsBadge ipsBadge--neutral">Basic</span>
						{{endif}}
					</td>
					<td>
						{{if $d['suspended']}}
							<span class="ipsBadge ipsBadge--negative">Suspended</span>
						{{elseif $d['active']}}
							<span class="ipsBadge ipsBadge--positive">Active</span>
						{{else}}
							<span class="ipsBadge ipsBadge--neutral">Inactive</span>
						{{endif}}
					</td>
					<td>{expression="number_format( $d['listing_count'] )"}</td>
					<td>
						{{if $d['last_run']}}
							{$d['last_run']}
							{{if $d['last_run_status'] === 'failed'}}
								<br><span class="ipsBadge ipsBadge--negative">Failed</span>
							{{endif}}
						{{else}}
							&mdash;
						{{endif}}
					</td>
					<td>{$d['mrr']}</td>
					<td>
						<a href="{$d['view_url']}" class="ipsButton ipsButton--small ipsButton--primary">View</a>
						<a href="{$d['edit_url']}" class="ipsButton ipsButton--small ipsButton--normal">Edit</a>
						<a href="{$d['import_url']}" class="ipsButton ipsButton--small ipsButton--normal">Import</a>
						{{if $d['suspended']}}
							<a href="{$d['suspend_url']}" class="ipsButton ipsButton--small ipsButton--positive">Unsuspend</a>
						{{else}}
							<a href="{$d['suspend_url']}" class="ipsButton ipsButton--small ipsButton--negative">Suspend</a>
						{{endif}}
					</td>
				</tr>
				{{endforeach}}
				{{if count( $dealers ) === 0}}
				<tr><td colspan="7" style="text-align:center;color:#999;padding:24px">No dealers yet. Dealers are created on first IPS Commerce subscription purchase.</td></tr>
				{{endif}}
			</tbody>
		</table>

	</div>
</div>
TEMPLATE_EOT,
	],

	/* ===== ADMIN: dealerDetail ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'admin',
		'group'         => 'dealers',
		'template_name' => 'dealerDetail',
		'template_data' => '$dealer, $logs, $listings, $backUrl, $editUrl, $importUrl, $suspendUrl',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div class="ipsBox_body ipsPad">

		<p><a href="{$backUrl}">&larr; Back to dealer list</a></p>

		<div style="display:flex;gap:16px;margin-bottom:24px;flex-wrap:wrap">
			<div class="ipsBox" style="flex:1 1 200px;padding:16px">
				<div style="color:#666;font-size:0.9em">Subscription Tier</div>
				<div style="font-weight:bold;margin-top:4px">{$dealer['subscription_tier']}</div>
			</div>
			<div class="ipsBox" style="flex:1 1 200px;padding:16px">
				<div style="color:#666;font-size:0.9em">MRR Contribution</div>
				<div style="font-weight:bold;margin-top:4px">{$dealer['mrr']}</div>
			</div>
			<div class="ipsBox" style="flex:1 1 200px;padding:16px">
				<div style="color:#666;font-size:0.9em">Feed Format</div>
				<div style="font-weight:bold;margin-top:4px">{$dealer['feed_format']}</div>
			</div>
			<div class="ipsBox" style="flex:1 1 200px;padding:16px">
				<div style="color:#666;font-size:0.9em">Schedule</div>
				<div style="font-weight:bold;margin-top:4px">{$dealer['import_schedule']}</div>
			</div>
			<div class="ipsBox" style="flex:1 1 200px;padding:16px">
				<div style="color:#666;font-size:0.9em">Last Record Count</div>
				<div style="font-weight:bold;margin-top:4px">{expression="number_format( $dealer['last_record_count'] )"}</div>
			</div>
		</div>

		<p><strong>Feed URL:</strong> <code>{$dealer['feed_url']}</code></p>
		<p><strong>API Key:</strong> <code>{$dealer['api_key']}</code></p>

		<div style="margin:16px 0">
			<a href="{$editUrl}" class="ipsButton ipsButton--primary">Edit Feed Config</a>
			<a href="{$importUrl}" class="ipsButton ipsButton--normal">Force Import Now</a>
			{{if $dealer['suspended']}}
				<a href="{$suspendUrl}" class="ipsButton ipsButton--positive">Unsuspend Dealer</a>
			{{else}}
				<a href="{$suspendUrl}" class="ipsButton ipsButton--negative">Suspend Dealer</a>
			{{endif}}
		</div>

		<h2>Recent Import Log</h2>
		<table class="ipsTable ipsTable_zebra" style="width:100%;margin-bottom:24px">
			<thead>
				<tr>
					<th>Started</th>
					<th>Status</th>
					<th>Total</th>
					<th>New</th>
					<th>Updated</th>
					<th>Unchanged</th>
					<th>Unmatched</th>
					<th>Drops</th>
				</tr>
			</thead>
			<tbody>
				{{foreach $logs as $l}}
				<tr>
					<td>{$l['run_start']}</td>
					<td>
						{{if $l['status'] === 'completed'}}
							<span class="ipsBadge ipsBadge--positive">OK</span>
						{{elseif $l['status'] === 'failed'}}
							<span class="ipsBadge ipsBadge--negative">Failed</span>
						{{else}}
							<span class="ipsBadge ipsBadge--warning">{$l['status']}</span>
						{{endif}}
					</td>
					<td>{$l['records_total']}</td>
					<td>{$l['records_created']}</td>
					<td>{$l['records_updated']}</td>
					<td>{$l['records_unchanged']}</td>
					<td>{$l['records_unmatched']}</td>
					<td>{$l['price_drops']}</td>
				</tr>
				{{if $l['error_log']}}
				<tr><td colspan="8"><pre style="white-space:pre-wrap;color:#c00;margin:0">{$l['error_log']}</pre></td></tr>
				{{endif}}
				{{endforeach}}
				{{if count( $logs ) === 0}}
				<tr><td colspan="8" style="text-align:center;color:#999;padding:24px">No imports have run for this dealer yet.</td></tr>
				{{endif}}
			</tbody>
		</table>

		<h2>Recent Listings</h2>
		<table class="ipsTable ipsTable_zebra" style="width:100%">
			<thead>
				<tr><th>UPC</th><th>Price</th><th>Stock</th><th>Status</th><th>Last Updated</th></tr>
			</thead>
			<tbody>
				{{foreach $listings as $l}}
				<tr>
					<td><code>{$l['upc']}</code></td>
					<td>{$l['dealer_price']}</td>
					<td>
						{{if $l['in_stock']}}
							<span class="ipsBadge ipsBadge--positive">In Stock</span>
						{{else}}
							<span class="ipsBadge ipsBadge--neutral">Out</span>
						{{endif}}
					</td>
					<td>{$l['listing_status']}</td>
					<td>{$l['last_updated']}</td>
				</tr>
				{{endforeach}}
				{{if count( $listings ) === 0}}
				<tr><td colspan="5" style="text-align:center;color:#999;padding:24px">No listings.</td></tr>
				{{endif}}
			</tbody>
		</table>

	</div>
</div>
TEMPLATE_EOT,
	],

	/* ===== ADMIN: mrrDashboard ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'admin',
		'group'         => 'dealers',
		'template_name' => 'mrrDashboard',
		'template_data' => '$totalMrr, $tierRows, $newSignups, $churn',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div class="ipsBox_body ipsPad">

		<div style="display:flex;gap:16px;margin-bottom:24px;flex-wrap:wrap">
			<div class="ipsBox" style="flex:1 1 200px;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$totalMrr}</div>
				<div>{lang="gddealer_mrr_total"}</div>
			</div>
			<div class="ipsBox" style="flex:1 1 200px;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold;color:#2a8a2a">{$newSignups}</div>
				<div>{lang="gddealer_mrr_new_signups"}</div>
			</div>
			<div class="ipsBox" style="flex:1 1 200px;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold;color:#c00">{$churn}</div>
				<div>{lang="gddealer_mrr_churn"}</div>
			</div>
		</div>

		<h2>{lang="gddealer_mrr_by_tier"}</h2>
		<table class="ipsTable ipsTable_zebra" style="width:100%">
			<thead>
				<tr><th>Tier</th><th>Dealers</th><th>MRR</th></tr>
			</thead>
			<tbody>
				{{foreach $tierRows as $r}}
				<tr>
					<td><strong>{$r['label']}</strong></td>
					<td>{$r['count']}</td>
					<td>{$r['mrr']}</td>
				</tr>
				{{endforeach}}
			</tbody>
		</table>

	</div>
</div>
TEMPLATE_EOT,
	],

	/* ===== ADMIN: unmatchedList ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'admin',
		'group'         => 'dealers',
		'template_name' => 'unmatchedList',
		'template_data' => '$rows, $total, $pagination',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div class="ipsBox_body ipsPad">

		<p>{expression="number_format( $total )"} unmatched UPCs across all dealer feeds.</p>

		<table class="ipsTable ipsTable_zebra" style="width:100%">
			<thead>
				<tr>
					<th>{lang="gddealer_unmatched_upc"}</th>
					<th>{lang="gddealer_unmatched_dealer"}</th>
					<th>{lang="gddealer_unmatched_first_seen"}</th>
					<th>{lang="gddealer_unmatched_last_seen"}</th>
					<th>{lang="gddealer_unmatched_count"}</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				{{foreach $rows as $r}}
				<tr>
					<td><code>{$r['upc']}</code></td>
					<td>{$r['dealer_name']}</td>
					<td>{$r['first_seen']}</td>
					<td>{$r['last_seen']}</td>
					<td>{$r['occurrence_count']}</td>
					<td>
						<a href="{$r['add_url']}" class="ipsButton ipsButton--small ipsButton--positive">{lang="gddealer_unmatched_add_to_catalog"}</a>
						<a href="{$r['exclude_url']}" class="ipsButton ipsButton--small ipsButton--neutral">{lang="gddealer_unmatched_exclude"}</a>
					</td>
				</tr>
				{{endforeach}}
				{{if count( $rows ) === 0}}
				<tr><td colspan="6" style="text-align:center;color:#999;padding:24px">No unmatched UPCs.</td></tr>
				{{endif}}
			</tbody>
		</table>

		<div style="margin-top:16px">{$pagination}</div>

	</div>
</div>
TEMPLATE_EOT,
	],
	/* ===== FRONT: notSubscribed ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'front',
		'group'         => 'dealers',
		'template_name' => 'notSubscribed',
		'template_data' => '$joinUrl',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox">
	<h1 class="ipsBox_title">{lang="gddealer_frontend_dashboard_title"}</h1>
	<div class="ipsPad">
		<p>{lang="gddealer_frontend_not_subscribed"}</p>
		<p style="margin-top:16px">
			<a href="{$joinUrl}" class="ipsButton ipsButton--primary">{lang="gddealer_front_join_cta"}</a>
		</p>
	</div>
</div>
TEMPLATE_EOT,
	],

	/* ===== FRONT: dealerShell (tab wrapper) ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'front',
		'group'         => 'dealers',
		'template_name' => 'dealerShell',
		'template_data' => '$dealer, $activeTab, $tabUrls, $body',
		'template_content' => <<<'TEMPLATE_EOT'
<div style="max-width:1200px;margin:0 auto;padding:24px 16px">

	<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid var(--i-border-color, #e0e0e0)">
		<div>
			<h1 style="margin:0;font-size:1.4em;font-weight:700">{$dealer['dealer_name']}</h1>
			<p style="margin:4px 0 0;color:#666;font-size:0.9em">
				{lang="gddealer_front_dashboard_welcome"} &mdash;
				<span style="background:#2563eb;color:#fff;padding:2px 8px;border-radius:12px;font-size:0.85em;font-weight:600">{$dealer['tier_label']}</span>
			</p>
		</div>
		<div>
			<a href="{$tabUrls['subscription']}" class="ipsButton ipsButton--normal ipsButton--small">{lang="gddealer_front_tab_subscription"}</a>
		</div>
	</div>

	{{if $dealer['suspended']}}
		<div class="ipsMessage ipsMessage_error" style="margin:16px 0">
			{lang="gddealer_front_suspended_banner"}
		</div>
	{{endif}}

	{{if $dealer['onboarding_incomplete']}}
		<div class="ipsMessage ipsMessage_warning" style="margin:16px 0">
			<p>{lang="gddealer_front_onboarding_incomplete"}</p>
			<p style="margin-top:8px">
				<a href="{$tabUrls['feedSettings']}" class="ipsButton ipsButton--primary ipsButton--small">{lang="gddealer_front_onboarding_go_settings"}</a>
			</p>
		</div>
	{{endif}}

	<div style="display:flex;gap:4px;margin:0 0 20px;padding-bottom:12px;border-bottom:1px solid var(--i-border-color, #e0e0e0);flex-wrap:wrap">
		<a href="{$tabUrls['overview']}" class="ipsButton ipsButton--small {expression="$activeTab === 'overview' ? 'ipsButton--primary' : 'ipsButton--normal'"}">{lang="gddealer_front_tab_overview"}</a>
		<a href="{$tabUrls['feedSettings']}" class="ipsButton ipsButton--small {expression="$activeTab === 'feedSettings' ? 'ipsButton--primary' : 'ipsButton--normal'"}">{lang="gddealer_front_tab_feed"}</a>
		<a href="{$tabUrls['listings']}" class="ipsButton ipsButton--small {expression="$activeTab === 'listings' ? 'ipsButton--primary' : 'ipsButton--normal'"}">{lang="gddealer_front_tab_listings"}</a>
		<a href="{$tabUrls['unmatched']}" class="ipsButton ipsButton--small {expression="$activeTab === 'unmatched' ? 'ipsButton--primary' : 'ipsButton--normal'"}">{lang="gddealer_front_tab_unmatched"}</a>
		<a href="{$tabUrls['analytics']}" class="ipsButton ipsButton--small {expression="$activeTab === 'analytics' ? 'ipsButton--primary' : 'ipsButton--normal'"}">{lang="gddealer_front_tab_analytics"}</a>
		<a href="{$tabUrls['subscription']}" class="ipsButton ipsButton--small {expression="$activeTab === 'subscription' ? 'ipsButton--primary' : 'ipsButton--normal'"}">{lang="gddealer_front_tab_subscription"}</a>
		<a href="{$tabUrls['help']}" class="ipsButton ipsButton--small {expression="$activeTab === 'help' ? 'ipsButton--primary' : 'ipsButton--normal'"}">{lang="gddealer_front_tab_help"}</a>
	</div>

	<div style="padding:8px 24px">
		{$body|raw}
	</div>

</div>
TEMPLATE_EOT,
	],

	/* ===== FRONT: overview tab body ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'front',
		'group'         => 'dealers',
		'template_name' => 'overview',
		'template_data' => '$dealer, $overview, $tabUrls',
		'template_content' => <<<'TEMPLATE_EOT'
<div>

	<div style="display:flex;gap:16px;margin-bottom:24px;flex-wrap:wrap">
		<div class="ipsBox" style="flex:1 1 180px;padding:16px;text-align:center">
			<div style="font-size:2em;font-weight:bold">{expression="number_format( $overview['active_listings'] )"}</div>
			<div>{lang="gddealer_front_active_listings"}</div>
		</div>
		<div class="ipsBox" style="flex:1 1 180px;padding:16px;text-align:center">
			<div style="font-size:2em;font-weight:bold;color:#c00">{expression="number_format( $overview['out_of_stock'] )"}</div>
			<div>{lang="gddealer_front_out_of_stock"}</div>
		</div>
		<div class="ipsBox" style="flex:1 1 180px;padding:16px;text-align:center">
			<div style="font-size:2em;font-weight:bold;color:#c96">{expression="number_format( $overview['unmatched_count'] )"}</div>
			<div>{lang="gddealer_front_unmatched_count"}</div>
		</div>
		<div class="ipsBox" style="flex:1 1 180px;padding:16px;text-align:center">
			<div style="font-size:2em;font-weight:bold">{expression="number_format( $overview['clicks_7d'] )"}</div>
			<div>{lang="gddealer_front_clicks_7d"}</div>
		</div>
		<div class="ipsBox" style="flex:1 1 180px;padding:16px;text-align:center">
			<div style="font-size:2em;font-weight:bold">{expression="number_format( $overview['clicks_30d'] )"}</div>
			<div>{lang="gddealer_front_clicks_30d"}</div>
		</div>
	</div>

	<h2>{lang="gddealer_front_last_import"}</h2>
	<p>
		{{if $overview['last_run_time']}}
			<strong>{$overview['last_run_time']}</strong> &mdash;
			{{if $overview['last_run_status'] === 'completed'}}
				<span class="ipsBadge ipsBadge--positive">Completed</span>
			{{elseif $overview['last_run_status'] === 'failed'}}
				<span class="ipsBadge ipsBadge--negative">Failed</span>
			{{elseif $overview['last_run_status'] === 'running'}}
				<span class="ipsBadge ipsBadge--warning">Running</span>
			{{else}}
				<span class="ipsBadge ipsBadge--neutral">{$overview['last_run_status']}</span>
			{{endif}}
			&mdash; {expression="number_format( $overview['last_run_total'] )"} records processed
			{{if $overview['last_run_errors']}}
				<br><span style="color:#c00">Errors were logged &mdash; see Feed Settings &rarr; Import History.</span>
			{{endif}}
		{{else}}
			<em>{lang="gddealer_front_last_import_none"}</em>
		{{endif}}
	</p>

</div>
TEMPLATE_EOT,
	],

	/* ===== FRONT: feedSettings tab body ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'front',
		'group'         => 'dealers',
		'template_name' => 'feedSettings',
		'template_data' => '$dealer, $form, $logs, $importUrl, $tabUrls',
		'template_content' => <<<'TEMPLATE_EOT'
<div>

	{$form|raw}

	<div style="margin:16px 0">
		<a href="{$importUrl}" class="ipsButton ipsButton--primary">{lang="gddealer_front_run_import"}</a>
	</div>

	<h2>{lang="gddealer_front_import_history"}</h2>
	<table class="ipsTable ipsTable_zebra" style="width:100%">
		<thead>
			<tr>
				<th>Started</th>
				<th>Status</th>
				<th>Total</th>
				<th>New</th>
				<th>Updated</th>
				<th>Unchanged</th>
				<th>Unmatched</th>
				<th>Drops</th>
			</tr>
		</thead>
		<tbody>
			{{foreach $logs as $l}}
			<tr>
				<td>{$l['run_start']}</td>
				<td>
					{{if $l['status'] === 'completed'}}
						<span class="ipsBadge ipsBadge--positive">OK</span>
					{{elseif $l['status'] === 'failed'}}
						<span class="ipsBadge ipsBadge--negative">Failed</span>
					{{else}}
						<span class="ipsBadge ipsBadge--warning">{$l['status']}</span>
					{{endif}}
				</td>
				<td>{$l['records_total']}</td>
				<td>{$l['records_created']}</td>
				<td>{$l['records_updated']}</td>
				<td>{$l['records_unchanged']}</td>
				<td>{$l['records_unmatched']}</td>
				<td>{$l['price_drops']}</td>
			</tr>
			{{if $l['error_log']}}
			<tr><td colspan="8"><pre style="white-space:pre-wrap;color:#c00;margin:0">{$l['error_log']}</pre></td></tr>
			{{endif}}
			{{endforeach}}
			{{if count( $logs ) === 0}}
			<tr><td colspan="8" style="text-align:center;color:#999;padding:24px">No imports have run yet.</td></tr>
			{{endif}}
		</tbody>
	</table>

</div>
TEMPLATE_EOT,
	],

	/* ===== FRONT: listings tab body ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'front',
		'group'         => 'dealers',
		'template_name' => 'listings',
		'template_data' => '$dealer, $rows, $total, $page, $pages, $baseUrl, $filter, $search, $exportUrl, $tabUrls',
		'template_content' => <<<'TEMPLATE_EOT'
<div>

	<form method="get" action="{$tabUrls['listings']}" style="display:flex;gap:8px;flex-wrap:wrap;align-items:end;margin-bottom:16px">
		<input type="hidden" name="app" value="gddealer">
		<input type="hidden" name="module" value="dealers">
		<input type="hidden" name="controller" value="dashboard">
		<input type="hidden" name="do" value="listings">
		<div>
			<label style="display:block;font-size:0.85em;color:#666">{lang="gddealer_front_filter"}</label>
			<select name="filter" style="border:1px solid var(--i-border-color,#ccc);border-radius:4px;padding:6px 10px;background:#fff">
				<option value="" {expression="$filter === '' ? 'selected' : ''"}>All</option>
				<option value="active" {expression="$filter === 'active' ? 'selected' : ''"}>Active</option>
				<option value="in_stock" {expression="$filter === 'in_stock' ? 'selected' : ''"}>In Stock</option>
				<option value="out_of_stock" {expression="$filter === 'out_of_stock' ? 'selected' : ''"}>Out of Stock</option>
				<option value="suspended" {expression="$filter === 'suspended' ? 'selected' : ''"}>Suspended</option>
				<option value="discontinued" {expression="$filter === 'discontinued' ? 'selected' : ''"}>Discontinued</option>
			</select>
		</div>
		<div>
			<label style="display:block;font-size:0.85em;color:#666">{lang="gddealer_front_search_upc"}</label>
			<input type="text" name="q" value="{$search}" placeholder="{lang='gddealer_front_search_placeholder'}" style="border:1px solid var(--i-border-color,#ccc);border-radius:4px;padding:6px 10px;background:#fff">
		</div>
		<button type="submit" class="ipsButton ipsButton--primary ipsButton--small">{lang="gddealer_front_apply"}</button>
		<a href="{$exportUrl}" class="ipsButton ipsButton--normal ipsButton--small">{lang="gddealer_front_export_csv"}</a>
	</form>

	<p style="color:#666">{expression="number_format( $total )"} listings total.</p>

	<table class="ipsTable ipsTable_zebra" style="width:100%">
		<thead>
			<tr>
				<th>{lang="gddealer_listing_upc"}</th>
				<th>{lang="gddealer_listing_price"}</th>
				<th>{lang="gddealer_listing_stock"}</th>
				<th>{lang="gddealer_listing_condition"}</th>
				<th>Status</th>
				<th>{lang="gddealer_listing_last_updated"}</th>
			</tr>
		</thead>
		<tbody>
			{{foreach $rows as $r}}
			<tr>
				<td><code>{$r['upc']}</code></td>
				<td>{$r['dealer_price']}</td>
				<td>
					{{if $r['in_stock']}}
						<span class="ipsBadge ipsBadge--positive">In Stock</span>
					{{else}}
						<span class="ipsBadge ipsBadge--neutral">Out</span>
					{{endif}}
				</td>
				<td>{$r['condition']}</td>
				<td>{$r['listing_status']}</td>
				<td>{$r['last_updated']}</td>
			</tr>
			{{endforeach}}
			{{if count( $rows ) === 0}}
			<tr><td colspan="6" style="text-align:center;color:#999;padding:24px">{lang="gddealer_front_listings_empty"}</td></tr>
			{{endif}}
		</tbody>
	</table>

	{{if $pages > 1}}
	<div style="margin-top:16px">
		Page {$page} of {$pages}
	</div>
	{{endif}}

</div>
TEMPLATE_EOT,
	],

	/* ===== FRONT: unmatched tab body ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'front',
		'group'         => 'dealers',
		'template_name' => 'unmatched',
		'template_data' => '$dealer, $rows, $exportUrl, $tabUrls',
		'template_content' => <<<'TEMPLATE_EOT'
<div>

	<p>{lang="gddealer_front_unmatched_intro"}</p>

	<p style="margin:8px 0 16px 0">
		<a href="{$exportUrl}" class="ipsButton ipsButton--normal ipsButton--small">{lang="gddealer_front_export_csv"}</a>
	</p>

	<table class="ipsTable ipsTable_zebra" style="width:100%">
		<thead>
			<tr>
				<th>{lang="gddealer_unmatched_upc"}</th>
				<th>{lang="gddealer_unmatched_first_seen"}</th>
				<th>{lang="gddealer_unmatched_last_seen"}</th>
				<th>{lang="gddealer_unmatched_count"}</th>
				<th></th>
			</tr>
		</thead>
		<tbody>
			{{foreach $rows as $r}}
			<tr>
				<td><code>{$r['upc']}</code></td>
				<td>{$r['first_seen']}</td>
				<td>{$r['last_seen']}</td>
				<td>{$r['occurrence_count']}</td>
				<td><a href="{$r['exclude_url']}" class="ipsButton ipsButton--small ipsButton--negative">{lang="gddealer_front_unmatched_exclude"}</a></td>
			</tr>
			{{endforeach}}
			{{if count( $rows ) === 0}}
			<tr><td colspan="5" style="text-align:center;color:#999;padding:24px">{lang="gddealer_front_unmatched_empty"}</td></tr>
			{{endif}}
		</tbody>
	</table>

</div>
TEMPLATE_EOT,
	],

	/* ===== FRONT: analytics tab body ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'front',
		'group'         => 'dealers',
		'template_name' => 'analytics',
		'template_data' => '$dealer, $gated, $topClicked, $tabUrls',
		'template_content' => <<<'TEMPLATE_EOT'
<div>

	{{if $gated}}
		<div class="ipsMessage ipsMessage_info">
			<h2>{lang="gddealer_front_analytics_gated_title"}</h2>
			<p>{lang="gddealer_front_analytics_gated_body"}</p>
			<p style="margin-top:8px">
				<a href="{$tabUrls['subscription']}" class="ipsButton ipsButton--primary">{lang="gddealer_front_subscription_manage"}</a>
			</p>
		</div>
	{{else}}
		<h2>{lang="gddealer_front_analytics_top_clicked"}</h2>
		<table class="ipsTable ipsTable_zebra" style="width:100%">
			<thead>
				<tr>
					<th>{lang="gddealer_listing_upc"}</th>
					<th>Price</th>
					<th>Clicks (30d)</th>
					<th>Clicks (7d)</th>
					<th>Status</th>
				</tr>
			</thead>
			<tbody>
				{{foreach $topClicked as $r}}
				<tr>
					<td><code>{$r['upc']}</code></td>
					<td>{$r['dealer_price']}</td>
					<td>{$r['clicks_30d']}</td>
					<td>{$r['clicks_7d']}</td>
					<td>{$r['listing_status']}</td>
				</tr>
				{{endforeach}}
				{{if count( $topClicked ) === 0}}
				<tr><td colspan="5" style="text-align:center;color:#999;padding:24px">{lang="gddealer_front_analytics_empty"}</td></tr>
				{{endif}}
			</tbody>
		</table>
	{{endif}}

</div>
TEMPLATE_EOT,
	],

	/* ===== FRONT: subscription tab body ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'front',
		'group'         => 'dealers',
		'template_name' => 'subscription',
		'template_data' => '$dealer, $sub, $tabUrls',
		'template_content' => <<<'TEMPLATE_EOT'
<div>

	<div style="display:flex;gap:16px;margin-bottom:24px;flex-wrap:wrap">
		<div class="ipsBox" style="flex:1 1 200px;padding:16px;text-align:center">
			<div style="color:#666;font-size:0.9em">{lang="gddealer_front_subscription_current"}</div>
			<div style="font-size:1.6em;font-weight:bold;margin-top:4px">{$sub['tier_label']}</div>
		</div>
		<div class="ipsBox" style="flex:1 1 200px;padding:16px;text-align:center">
			<div style="color:#666;font-size:0.9em">{lang="gddealer_front_subscription_mrr"}</div>
			<div style="font-size:1.6em;font-weight:bold;margin-top:4px">{$sub['mrr']}</div>
		</div>
		<div class="ipsBox" style="flex:1 1 200px;padding:16px;text-align:center">
			<div style="color:#666;font-size:0.9em">{lang="gddealer_front_subscription_status"}</div>
			<div style="font-size:1.2em;font-weight:bold;margin-top:4px">
				{{if $sub['suspended']}}
					<span class="ipsBadge ipsBadge--negative">Suspended</span>
				{{elseif $sub['active']}}
					<span class="ipsBadge ipsBadge--positive">Active</span>
				{{else}}
					<span class="ipsBadge ipsBadge--neutral">Pending Setup</span>
				{{endif}}
			</div>
		</div>
	</div>

	<p>{lang="gddealer_front_subscription_note"}</p>

</div>
TEMPLATE_EOT,
	],

	/* ===== FRONT: help tab body ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'front',
		'group'         => 'dealers',
		'template_name' => 'help',
		'template_data' => '',
		'template_content' => <<<'TEMPLATE_EOT'
<div style="max-width:800px">

	<h2 style="margin:0 0 4px">Feed Setup Guide</h2>
	<p style="color:#666;margin:0 0 24px">Follow these steps to get your inventory syncing with GunRack.deals.</p>

	<div style="background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;padding:20px;margin-bottom:16px">
		<h3 style="margin:0 0 12px;font-size:1.05em;font-weight:700;color:#1e3a5f">
			<span style="background:#2563eb;color:#fff;border-radius:50%;width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;font-size:0.8em;margin-right:8px;font-weight:700">1</span>
			Prepare your product feed
		</h3>
		<p>Your feed must be a publicly accessible URL that returns product data in one of our supported formats: <strong>XML, JSON, or CSV</strong>. The feed must be reachable by our servers without authentication, or use Basic Auth or an API key.</p>
		<p><strong>Required fields per product:</strong></p>
		<ul style="margin:8px 0;padding-left:20px">
			<li><strong>UPC</strong> &mdash; 12-digit UPC barcode. Must match our catalog exactly.</li>
			<li><strong>Price</strong> &mdash; Your retail price as a decimal (e.g. 499.99)</li>
			<li><strong>In Stock</strong> &mdash; Boolean or quantity (0/1, true/false, or quantity integer)</li>
		</ul>
		<p><strong>Optional but recommended:</strong></p>
		<ul style="margin:8px 0;padding-left:20px">
			<li><strong>SKU</strong> &mdash; Your internal product identifier</li>
			<li><strong>Shipping Cost</strong> &mdash; Flat shipping fee. Use 0 for free shipping.</li>
			<li><strong>Condition</strong> &mdash; new, used, or refurbished</li>
			<li><strong>Product URL</strong> &mdash; Direct link to the product on your website</li>
			<li><strong>Stock Quantity</strong> &mdash; Exact quantity on hand</li>
		</ul>
	</div>

	<div style="background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;padding:20px;margin-bottom:16px">
		<h3 style="margin:0 0 12px;font-size:1.05em;font-weight:700;color:#1e3a5f">
			<span style="background:#2563eb;color:#fff;border-radius:50%;width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;font-size:0.8em;margin-right:8px;font-weight:700">2</span>
			Format your feed
		</h3>

		<p><strong>CSV format example:</strong></p>
		<pre style="background:#f4f4f4;padding:12px;border-radius:4px;overflow-x:auto;font-size:0.85em">upc,price,in_stock,shipping_cost,condition,product_url
026495088565,499.99,1,15.00,new,https://yourstore.com/product/123
000000000000,299.99,0,0.00,new,https://yourstore.com/product/456</pre>

		<p style="margin-top:16px"><strong>JSON format example:</strong></p>
		<pre style="background:#f4f4f4;padding:12px;border-radius:4px;overflow-x:auto;font-size:0.85em">[
  {
    "upc": "026495088565",
    "price": 499.99,
    "in_stock": true,
    "shipping_cost": 15.00,
    "condition": "new",
    "product_url": "https://yourstore.com/product/123"
  }
]</pre>

		<p style="margin-top:16px"><strong>XML format example:</strong></p>
		<pre style="background:#f4f4f4;padding:12px;border-radius:4px;overflow-x:auto;font-size:0.85em">&lt;products&gt;
  &lt;product&gt;
    &lt;upc&gt;026495088565&lt;/upc&gt;
    &lt;price&gt;499.99&lt;/price&gt;
    &lt;in_stock&gt;1&lt;/in_stock&gt;
    &lt;shipping_cost&gt;15.00&lt;/shipping_cost&gt;
    &lt;condition&gt;new&lt;/condition&gt;
  &lt;/product&gt;
&lt;/products&gt;</pre>
	</div>

	<div style="background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;padding:20px;margin-bottom:16px">
		<h3 style="margin:0 0 12px;font-size:1.05em;font-weight:700;color:#1e3a5f">
			<span style="background:#2563eb;color:#fff;border-radius:50%;width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;font-size:0.8em;margin-right:8px;font-weight:700">3</span>
			Configure field mapping
		</h3>
		<p>If your feed uses different field names than our defaults, enter a JSON mapping in the Field Mapping box on the Feed Settings tab. Map your field names to ours:</p>
		<pre style="background:#f4f4f4;padding:12px;border-radius:4px;overflow-x:auto;font-size:0.85em">{
  "UPC": "upc",
  "PRICE": "dealer_price",
  "QTY": "stock_qty",
  "INSTOCK": "in_stock",
  "SHIP": "shipping_cost",
  "COND": "condition",
  "URL": "listing_url"
}</pre>
	</div>

	<div style="background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;padding:20px;margin-bottom:16px">
		<h3 style="margin:0 0 12px;font-size:1.05em;font-weight:700;color:#1e3a5f">
			<span style="background:#2563eb;color:#fff;border-radius:50%;width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;font-size:0.8em;margin-right:8px;font-weight:700">4</span>
			Enter your feed URL
		</h3>
		<p>Go to the <strong>Feed Settings</strong> tab and enter your feed URL. Select your format (CSV, JSON, or XML). If your feed requires authentication, select the auth type and enter your credentials as JSON:</p>
		<ul style="margin:8px 0;padding-left:20px">
			<li>Basic Auth: <code style="background:#f4f4f4;padding:1px 6px;border-radius:3px">{"username":"user","password":"pass"}</code></li>
			<li>API Key: <code style="background:#f4f4f4;padding:1px 6px;border-radius:3px">{"api_key":"your-key-here"}</code></li>
		</ul>
		<p>Click <strong>Save Feed Settings</strong> then <strong>Run Import Now</strong> to trigger your first sync immediately.</p>
	</div>

	<div style="background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;padding:20px;margin-bottom:24px">
		<h3 style="margin:0 0 12px;font-size:1.05em;font-weight:700;color:#1e3a5f">
			<span style="background:#2563eb;color:#fff;border-radius:50%;width:24px;height:24px;display:inline-flex;align-items:center;justify-content:center;font-size:0.8em;margin-right:8px;font-weight:700">5</span>
			Review your listings
		</h3>
		<p>After your first import completes, go to the <strong>Listings</strong> tab to see all synced products. Check the <strong>Unmatched UPCs</strong> tab for any products that couldn't be matched to our catalog &mdash; these won't appear in search results until the UPC is added to our database.</p>
		<p>If you have unmatched UPCs, contact us and we'll add them to the catalog promptly.</p>
	</div>

	<div style="background:#f0f7ff;border:1px solid #bfdbfe;border-radius:6px;padding:16px">
		<h3 style="margin:0 0 8px;color:#1e40af">Feed Requirements Summary</h3>
		<ul style="margin:0;padding-left:20px;color:#1e3a5f">
			<li>Feed URL must be publicly accessible or use supported auth</li>
			<li>UPC must be a valid 12-digit barcode matching our catalog</li>
			<li>Price must be a positive decimal number</li>
			<li>Feed must update at least daily &mdash; stale feeds cause listings to go out of stock</li>
			<li>Do not include products you are not licensed to sell in Illinois</li>
			<li>Handgun listings require valid FFL documentation on file with us</li>
		</ul>
	</div>

	<p style="margin-top:24px;color:#666">Questions? Contact us at <a href="mailto:dealers@gunrack.deals">dealers@gunrack.deals</a></p>
</div>
TEMPLATE_EOT,
	],

	/* ===== FRONT: join (landing) ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'front',
		'group'         => 'dealers',
		'template_name' => 'join',
		'template_data' => '$tiers, $requestUrl',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div class="ipsBox_body ipsPad">

		<h1 class="ipsType_pageTitle">{lang="gddealer_front_join_title"}</h1>
		<p style="max-width:720px">{lang="gddealer_front_join_intro"}</p>

		<div style="display:flex;gap:20px;margin:32px 0;flex-wrap:wrap;align-items:stretch">
			{{foreach $tiers as $t}}
			<div class="ipsBox" style="{expression="$t['featured'] ? 'flex:1 1 280px;padding:28px 24px;border:2px solid #3b82f6;box-shadow:0 4px 16px rgba(59,130,246,0.15);position:relative;display:flex;flex-direction:column' : 'flex:1 1 280px;padding:28px 24px;border:1px solid #ddd;display:flex;flex-direction:column'"}">
				{{if $t['featured']}}
				<div style="position:absolute;top:-12px;right:16px;background:#3b82f6;color:#fff;padding:4px 12px;border-radius:12px;font-size:0.75em;font-weight:bold;text-transform:uppercase;letter-spacing:0.5px">Most Popular</div>
				{{endif}}
				<h2 style="margin:0 0 4px 0;font-size:1.4em">{$t['label']}</h2>
				<div style="font-size:2em;font-weight:bold;margin:8px 0;color:#111">{$t['price']}</div>
				<div style="color:#666;margin-bottom:20px;font-size:0.9em">{lang="gddealer_front_join_tier_schedule"} <strong>{$t['schedule']}</strong></div>
				<ul style="list-style:none;padding:0;margin:0 0 20px 0;flex:1">
					{{foreach $t['features'] as $f}}
					<li style="padding:6px 0 6px 26px;position:relative;line-height:1.4">
						<span style="position:absolute;left:0;top:6px;color:#10b981;font-weight:bold">&#10003;</span>
						{$f}
					</li>
					{{endforeach}}
				</ul>
				<a href="{$t['commerce_url']}" class="ipsButton {expression="$t['featured'] ? 'ipsButton--primary' : 'ipsButton--normal'"}" style="width:100%;text-align:center;margin-top:auto">Get Started</a>
			</div>
			{{endforeach}}
		</div>

		<p style="margin-top:24px;color:#666;font-size:0.9em">
			Not ready to sign up? <a href="{$requestUrl}">Request more information</a> and our team will reach out.
		</p>

	</div>
</div>
TEMPLATE_EOT,
	],

	/* ===== FRONT: joinRequest (contact form) ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'front',
		'group'         => 'dealers',
		'template_name' => 'joinRequest',
		'template_data' => '$form',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox">
	<div class="ipsPad">
		<h1 class="ipsType_pageTitle">{lang="gddealer_front_request_title"}</h1>
		<p style="max-width:720px">{lang="gddealer_front_request_intro"}</p>
		{$form|raw}
	</div>
</div>
TEMPLATE_EOT,
	],

	/* ===== FRONT: joinThanks ===== */
	[
		'set_id'        => 1,
		'app'           => 'gddealer',
		'location'      => 'front',
		'group'         => 'dealers',
		'template_name' => 'joinThanks',
		'template_data' => '',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox">
	<div class="ipsPad">
		<h1 class="ipsType_pageTitle">{lang="gddealer_front_thanks_title"}</h1>
		<p>{lang="gddealer_front_thanks_body"}</p>
	</div>
</div>
TEMPLATE_EOT,
	],
];

foreach ( $gddealerTemplates as $tpl )
{
	\IPS\Db::i()->insert( 'core_theme_templates', [
		'template_set_id'   => $tpl['set_id'],
		'template_app'      => $tpl['app'],
		'template_location' => $tpl['location'],
		'template_group'    => $tpl['group'],
		'template_name'     => $tpl['template_name'],
		'template_data'     => $tpl['template_data'],
		'template_content'  => $tpl['template_content'],
	]);
}
